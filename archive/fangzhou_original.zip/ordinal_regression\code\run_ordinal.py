"""Assignment 3 main analysis: ordinal logistic regression of B10 following the Assignment 2 protocol.

Protocol (Assignment 2, Sections 2-5): primary population = single or engaged respondents with known
nationality; six core items C1, C9, C14, E3, E13, F9; controls gender, student/employee role (Both ->
student), age group, questionnaire language and an engaged indicator; nationality main effect, with the
six nationality x item interactions as a secondary joint test; Monte Carlo scenarios raising C1, C9 or
C14 by one category (S = 1000); D1 awareness and D8.1 usefulness as separate extensions.

Run:  python run_ordinal.py [path/to/Updated Synthetic Data.xlsx]
Reads the data file (default ../Updated Synthetic Data.xlsx; not modified) and writes tables, figures and results.json
to the folder containing this script.
"""
import hashlib, json, sys
from pathlib import Path

import numpy as np
import pandas as pd
import scipy.stats as st
import statsmodels.api as sm
from statsmodels.miscmodels.ordinal_model import OrderedModel
from statsmodels.stats.outliers_influence import variance_inflation_factor
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

HERE = Path(__file__).resolve().parent
SOURCE = Path(sys.argv[1]) if len(sys.argv) > 1 else HERE.parent / "Updated Synthetic Data.xlsx"
SEED, S = 701, 1000
OUTCOME = "b10_overall_family_readiness"
ITEMS = {
    "C1 Employment confidence": "c1_employment_confidence",
    "C9 Housing access": "c9_housing_access",
    "C14 Financial preparedness": "c14_financially_prepared",
    "E3 Family support raises confidence": "e3_family_support_confidence",
    "E13 Future confidence would encourage": "e13_future_confidence",
    "F9 Work-life balance would encourage": "f9_worklife_balance",
}
SCENARIO_ITEMS = list(ITEMS)[:3]
NAT = "Emirati (vs non-Emirati)"
BLUE, ORANGE, INK, MUTED, GRID = "#2a78d6", "#eb6834", "#0b0b0b", "#52514e", "#e4e3df"


def prepare(raw):
    d = raw[raw.a6n_emirati.isin(["Yes", "No"])].copy()
    d = d[(d.a3_gender != "Prefer not to answer") & (d.a2_age_group != "Prefer not to answer")
          & (d.a7_marital_status != "Prefer not to answer")]
    d = d.dropna(subset=[OUTCOME, *ITEMS.values()])
    d["emirati"] = (d.a6n_emirati == "Yes").astype(float)
    d["role"] = d.a4_role.replace({"Both": "Student"})
    d["age"] = d.a2_age_group.str.replace(" years", "").replace(
        {"31-40": "31 or above", "41-50": "31 or above", "51 or above": "31 or above"})
    d["marital"] = d.a7_marital_status.replace({"Widowed": "Divorced/widowed", "Divorced": "Divorced/widowed"})
    return d.reset_index(drop=True)


def sample_flow(raw):
    steps = [("Synthetic responses", len(raw))]
    d = raw[raw.a6n_emirati.isin(["Yes", "No"])]
    steps.append(("Known nationality", len(d)))
    d = d[d.a7_marital_status.isin(["Single", "Engaged"])]
    steps.append(("Single or engaged (primary population)", len(d)))
    d = d[(d.a3_gender != "Prefer not to answer") & (d.a2_age_group != "Prefer not to answer")]
    steps.append(("Gender and age group reported (analysed)", len(d.dropna(subset=[OUTCOME, *ITEMS.values()]))))
    return steps


def design(d, categorical_items=False, marital=False, extra=()):
    q = d[list(ITEMS.values())].rename(columns={v: k for k, v in ITEMS.items()}).astype(float)
    if categorical_items:
        q = q.clip(lower=2).astype(int).astype(str)  # level 1 is sparse; merged with 2
        q = pd.get_dummies(q, dtype=float).drop(columns=[f"{k}_2" for k in ITEMS])
    x = q.copy()
    x[NAT] = d.emirati
    x["Gender: male"] = (d.a3_gender == "Male").astype(float)
    x["Role: employee"] = (d.role == "Employee").astype(float)
    for a in ["21-25", "26-30", "31 or above"]:
        x[f"Age: {a}"] = (d.age == a).astype(float)
    x["Language: Arabic"] = (d.a0_survey_language == "Arabic").astype(float)
    if marital:
        for m in ["Engaged", "Married", "Divorced/widowed"]:
            x[f"Marital: {m.lower()}"] = (d.marital == m).astype(float)
    else:
        x["Engaged (vs single)"] = (d.marital == "Engaged").astype(float)
    for name, series in extra:
        x[name] = series.to_numpy()
    return x


def fit(y, x):
    r = OrderedModel(y, x, distr="logit").fit(method="bfgs", maxiter=5000, disp=False)
    if not r.mle_retvals["converged"]:
        r = OrderedModel(y, x, distr="logit").fit(method="newton", maxiter=200, disp=False, start_params=r.params)
    assert r.mle_retvals["converged"], "ordinal model did not converge"
    return r


def null_llf(y):
    return float(np.log(y.map(y.value_counts(normalize=True))).sum())


def brant_test(y, x):
    """Brant (1990) Wald test of equal slopes across the four cumulative binary logits."""
    a = sm.add_constant(x, has_constant="add").to_numpy()
    fits = [sm.GLM((y > k).astype(int), a, family=sm.families.Binomial()).fit() for k in range(1, 5)]
    pis = [f.fittedvalues.to_numpy() for f in fits]
    inv = [np.linalg.inv(a.T @ (a * (p * (1 - p))[:, None])) for p in pis]
    p, J = x.shape[1], 4
    V = np.zeros((J * p, J * p))
    for m in range(J):
        for l in range(m, J):
            w = pis[l] * (1 - pis[m]) if l > m else pis[m] * (1 - pis[m])
            block = (inv[m] @ (a.T @ (a * w[:, None])) @ inv[l])[1:, 1:]
            V[m*p:(m+1)*p, l*p:(l+1)*p] = block
            V[l*p:(l+1)*p, m*p:(m+1)*p] = block.T
    beta = np.concatenate([f.params[1:] for f in fits])
    D = np.zeros(((J - 1) * p, J * p))
    for r in range(J - 1):
        D[r*p:(r+1)*p, :p] = np.eye(p)
        D[r*p:(r+1)*p, (r+1)*p:(r+2)*p] = -np.eye(p)
    rows = []
    for name, cols in [("Omnibus", list(range(p)))] + [(t, [j]) for j, t in enumerate(x.columns)]:
        sel = [r*p + j for r in range(J - 1) for j in cols]
        dd = D[sel] @ beta
        stat = float(dd @ np.linalg.solve(D[sel] @ V @ D[sel].T, dd))
        rows.append({"term": name, "chi2": stat, "df": len(sel), "p": float(st.chi2.sf(stat, len(sel)))})
    return pd.DataFrame(rows)


def cat_probs(params, x, k):
    """Category probabilities for an OrderedModel parameter vector (statsmodels threshold coding)."""
    b, t = params[:k], params[k:]
    cuts = np.concatenate([[t[0]], t[0] + np.cumsum(np.exp(t[1:]))])
    cum = 1 / (1 + np.exp(-(cuts[None, :] - (x @ b)[:, None])))
    cum = np.hstack([np.zeros((len(x), 1)), cum, np.ones((len(x), 1))])
    return np.diff(cum, axis=1)


def summarise(point, sims):
    return point, np.percentile(sims, 2.5, 0), np.percentile(sims, 97.5, 0)


def fmt_p(p):
    return "$<$0.001" if p < 0.001 else f"{p:.3f}"


def ptxt(p):
    return "$p<0.001$" if p < 0.001 else f"$p={p:.3f}$"


def tex(s):
    s = s.replace("&", r"\&").replace("%", r"\%").replace("_", r"\_")
    for a in ["21-25", "26-30", "18-20"]:
        s = s.replace(a, a.replace("-", "--"))
    return s


def main():
    raw = pd.read_excel(SOURCE)
    full = prepare(raw)
    d = full[full.marital.isin(["Single", "Engaged"])].reset_index(drop=True)
    y = d[OUTCOME].astype(int)
    x = design(d)
    k = x.shape[1]
    res = fit(y, x)
    params, cov = res.params.to_numpy(), res.cov_params().to_numpy()
    rng = np.random.default_rng(SEED)
    draws = rng.multivariate_normal(params, cov, S)
    ll0, ll1 = null_llf(y), float(res.llf)
    lr, lr_p = 2 * (ll1 - ll0), float(st.chi2.sf(2 * (ll1 - ll0), k))
    item_cols = list(ITEMS)

    def drop_lr(cols):
        s = 2 * (ll1 - fit(y, x.drop(columns=cols)).llf)
        return float(s), len(cols), float(st.chi2.sf(s, len(cols)))
    blocks = {"items": drop_lr(item_cols), "nationality": drop_lr([NAT]),
              "controls": drop_lr([c for c in x.columns if c not in item_cols and c != NAT])}

    ci = res.conf_int().iloc[:k]
    coef = pd.DataFrame({"term": x.columns, "beta": params[:k], "se": res.bse[:k].values, "OR": np.exp(params[:k]),
                         "OR_low": np.exp(ci[0].values), "OR_high": np.exp(ci[1].values), "p": res.pvalues[:k].values})
    coef.to_csv(HERE / "ordinal_coefficients.csv", index=False)
    cuts = np.concatenate([[params[k]], params[k] + np.cumsum(np.exp(params[k + 1:]))])

    # --- Secondary: nationality x item interactions (items centred at pooled means) ---
    inter = [(f"Emirati x {n}", d.emirati * (x[n] - x[n].mean())) for n in item_cols]
    xi = pd.concat([x.assign(**{n: x[n] - x[n].mean() for n in item_cols}),
                    pd.DataFrame({n: s for n, s in inter})], axis=1)
    res_i = fit(y, xi)
    int_lr = float(2 * (res_i.llf - ll1)); int_p = float(st.chi2.sf(int_lr, len(inter)))
    ci_cov = res_i.cov_params()
    group_or = []
    for n in item_cols:
        i = f"Emirati x {n}"
        bn, be = res_i.params[n], res_i.params[n] + res_i.params[i]
        sn = np.sqrt(ci_cov.loc[n, n]); se = np.sqrt(ci_cov.loc[n, n] + ci_cov.loc[i, i] + 2 * ci_cov.loc[n, i])
        group_or.append({"term": n, "OR_emi": np.exp(be), "lo_emi": np.exp(be - 1.96 * se), "hi_emi": np.exp(be + 1.96 * se),
                         "OR_non": np.exp(bn), "lo_non": np.exp(bn - 1.96 * sn), "hi_non": np.exp(bn + 1.96 * sn),
                         "p_diff": float(res_i.pvalues[i])})
    group_or = pd.DataFrame(group_or)
    group_or.to_csv(HERE / "group_odds_ratios.csv", index=False)

    # --- Nationality contrast on the common-support set (role x age cells with >= 3 per group) ---
    cell = d.role + " / " + d.age
    counts = pd.crosstab(cell, d.emirati)
    supported = counts[(counts[0.0] >= 3) & (counts[1.0] >= 3)].index
    cs = cell.isin(supported).to_numpy()
    xa = x[cs].to_numpy(); j = list(x.columns).index(NAT)
    def nat_probs(p, val):
        xx = xa.copy(); xx[:, j] = val
        return cat_probs(p, xx, k).mean(0)
    sims = {v: np.array([nat_probs(p, v) for p in draws]) for v in (1.0, 0.0)}
    pe, pn = nat_probs(params, 1.0), nat_probs(params, 0.0)
    pp = pd.DataFrame({"B10": range(1, 6)})
    for lab, pt, sm_ in [("Emirati", pe, sims[1.0]), ("Non-Emirati", pn, sims[0.0]), ("diff", pe - pn, sims[1.0] - sims[0.0])]:
        pp[lab], pp[f"{lab}_low"], pp[f"{lab}_high"] = summarise(pt, sm_)
    pp.to_csv(HERE / "predicted_probabilities.csv", index=False)
    high = {g: summarise(pt[3:].sum(), sm_[:, 3:].sum(1)) for g, pt, sm_ in
            [("Emirati", pe, sims[1.0]), ("Non-Emirati", pn, sims[0.0]), ("diff", pe - pn, sims[1.0] - sims[0.0])]}

    # --- Monte Carlo scenarios: raise C1, C9 or C14 by one category (capped at 5), by nationality ---
    scen = []
    for g, val in [("Emirati", 1.0), ("Non-Emirati", 0.0)]:
        xg = x[d.emirati == val].to_numpy()
        base = np.array([cat_probs(p, xg, k)[:, 3:].sum(1).mean() for p in draws])
        base_pt = cat_probs(params, xg, k)[:, 3:].sum(1).mean()
        for n in SCENARIO_ITEMS:
            xs = xg.copy(); c = list(x.columns).index(n); xs[:, c] = np.minimum(xs[:, c] + 1, 5)
            delta = np.array([cat_probs(p, xs, k)[:, 3:].sum(1).mean() for p in draws]) - base
            pt = cat_probs(params, xs, k)[:, 3:].sum(1).mean() - base_pt
            scen.append({"group": g, "n": int(len(xg)), "item": n, "baseline": base_pt, "delta": pt,
                         "low": np.percentile(delta, 2.5), "high": np.percentile(delta, 97.5),
                         "share_at_5": float((xg[:, c] == 5).mean())})
    scen = pd.DataFrame(scen)
    scen.to_csv(HERE / "scenarios.csv", index=False)

    # --- Diagnostics ---
    pred = np.asarray(res.predict(x.to_numpy())); pred_cat = pred.argmax(1) + 1
    xc = sm.add_constant(x).to_numpy()
    vif = pd.Series([variance_inflation_factor(xc, i + 1) for i in range(k)], index=x.columns)
    vif.to_csv(HERE / "vif.csv")
    brant = brant_test(y, x); brant.to_csv(HERE / "brant_test.csv", index=False)
    obs = y.value_counts(normalize=True).reindex(range(1, 6), fill_value=0)

    # --- Sensitivity and extensions ---
    sens = {}
    yw = full[OUTCOME].astype(int); xw = design(full, marital=True); rw = fit(yw, xw)
    sens[f"Wider sample ($n={len(full)}$)"] = (np.exp(rw.params[item_cols + [NAT]]), len(full))
    r12 = fit((y.clip(lower=2) - 1), x)
    sens["B10 1--2 merged"] = (np.exp(r12.params[item_cols + [NAT]]), len(d))
    xcat = design(d, categorical_items=True); rcat = fit(y, xcat)
    cat_lr = float(2 * (rcat.llf - ll1)); cat_df = xcat.shape[1] - k; cat_p = float(st.chi2.sf(cat_lr, cat_df))
    cat_names = [c for c in xcat.columns if c[:-2] in ITEMS]
    cat_terms = pd.DataFrame({"OR": np.exp(rcat.params[cat_names]), "p": rcat.pvalues[cat_names]})
    cat_terms.to_csv(HERE / "categorical_items.csv")

    # D1 awareness: 1 = at least one listed initiative, 0 = explicit "None of the above"; Unsure/Other-only -> missing
    listed = d.d1_heard_initiatives.fillna("").str.split(";").apply(
        lambda t: any(s.strip() not in ("None of the above", "Unsure", "Other", "") for s in t))
    none = d.d1_heard_initiatives.fillna("").str.strip() == "None of the above"
    d1_ok = (listed | none).to_numpy()
    d1 = listed.astype(float)[d1_ok].reset_index(drop=True)
    yd, xd = y[d1_ok].reset_index(drop=True), x[d1_ok].reset_index(drop=True)
    t1 = "D1 Recognises an initiative"
    r_core1, r_d1 = fit(yd, xd), fit(yd, xd.assign(**{t1: d1}))
    d1_res = {"n": int(d1_ok.sum()), "n_none": int((d1 == 0).sum()),
              "n_none_emirati": int(((d1 == 0) & (xd[NAT] == 1)).sum()),
              "OR": float(np.exp(r_d1.params[t1])), "low": float(np.exp(r_d1.conf_int().loc[t1, 0])),
              "high": float(np.exp(r_d1.conf_int().loc[t1, 1])), "LR": float(2 * (r_d1.llf - r_core1.llf)),
              "p": float(r_d1.pvalues[t1]), "aic_core": float(r_core1.aic), "aic_ext": float(r_d1.aic)}

    # D8.1 usefulness: respondents naming a programme (D12), reporting eligibility (D13 = Yes) and rating D8.1
    ok8 = ((d.d13_reported_eligibility == "Yes") & d.d8_programme_confidence.notna()
           & (d.d12_most_relevant_programme != "None that I can identify")).to_numpy()
    y8, x8 = y[ok8].reset_index(drop=True), x[ok8].reset_index(drop=True)
    d81 = d.d8_programme_confidence[ok8].astype(float).reset_index(drop=True)
    t8 = "D8.1 Programme increases confidence"
    r_core8, r_d8 = fit(y8, x8), fit(y8, x8.assign(**{t8: d81}))
    d8_res = {"n": int(ok8.sum()), "n_emirati": int(d.emirati[ok8].sum()),
              "OR": float(np.exp(r_d8.params[t8])), "low": float(np.exp(r_d8.conf_int().loc[t8, 0])),
              "high": float(np.exp(r_d8.conf_int().loc[t8, 1])), "LR": float(2 * (r_d8.llf - r_core8.llf)),
              "p": float(r_d8.pvalues[t8]), "aic_core": float(r_core8.aic), "aic_ext": float(r_d8.aic)}
    sens[f"Core, D8.1 subset ($n={d8_res['n']}$)"] = (np.exp(r_core8.params[item_cols + [NAT]]), d8_res["n"])
    sens_df = pd.DataFrame({"Primary": np.exp(params[:len(item_cols) + 1]), **{c: v[0].values for c, v in sens.items()}},
                           index=item_cols + [NAT])
    sens_df.to_csv(HERE / "sensitivity_or.csv")

    ame = {}
    for n in item_cols:
        xx = x.copy(); xx[n] = (xx[n] + 1).clip(upper=5)
        ame[n] = float(np.asarray(res.predict(xx.to_numpy()))[:, 3:].sum(1).mean() - pred[:, 3:].sum(1).mean())

    nat_lab = pd.Series(np.where(d.emirati == 1, "Emirati", "Non-Emirati"))
    item_means = d[list(ITEMS.values()) + [OUTCOME]].groupby(nat_lab).mean().round(2)
    fam = pd.crosstab(nat_lab, d.a20_family_location, normalize="index").round(3)
    lang = pd.crosstab(nat_lab, d.a0_survey_language)

    write_tables(coef, cuts, blocks, res, ll0, lr, lr_p, k, len(d), pp, group_or, int_lr, int_p,
                 scen, brant, vif, sens_df, d1_res, d8_res, cat_lr, cat_df, cat_p, int(cs.sum()), list(supported))
    figures(coef, pp, item_cols)

    results = {
        "data_status": "synthetic data (Updated Synthetic Data.xlsx); no population or causal claims",
        "source_sha256": hashlib.sha256(SOURCE.read_bytes()).hexdigest(),
        "sample_flow": sample_flow(raw), "n": len(d), "n_emirati": int(d.emirati.sum()),
        "n_non_emirati": int((1 - d.emirati).sum()), "n_engaged": int((d.marital == "Engaged").sum()),
        "b10_by_nationality": {g: {int(a): int(b) for a, b in r.items()} for g, r in
                               pd.crosstab(nat_lab, y.values).to_dict(orient="index").items()},
        "language_by_nationality": lang.to_dict(orient="index"),
        "item_means_by_nationality": item_means.to_dict(orient="index"),
        "family_location_by_nationality": fam.to_dict(orient="index"),
        "llf": ll1, "llf_null": ll0, "LR": lr, "LR_df": k, "LR_p": lr_p, "McFadden_R2": 1 - ll1 / ll0,
        "AIC": float(res.aic), "blocks": blocks, "cutpoints": cuts.tolist(),
        "accuracy_modal": float((pred_cat == y).mean()), "accuracy_majority": float(obs.max()),
        "within_one": float((abs(pred_cat - y) <= 1).mean()),
        "calibration": {"observed": obs.round(4).tolist(), "mean_predicted": pred.mean(0).round(4).tolist()},
        "common_support_cells": list(supported), "n_common_support": int(cs.sum()),
        "high_readiness_common_support": {g: [float(v) for v in t] for g, t in high.items()},
        "interaction_LR": int_lr, "interaction_df": len(inter), "interaction_p": int_p,
        "brant_omnibus": brant.iloc[0].to_dict(),
        "brant_min_p_items_nat": float(brant[brant.term.isin(item_cols + [NAT])].p.min()),
        "max_VIF": float(vif.max()), "max_VIF_term": vif.idxmax(), "max_VIF_items": float(vif[item_cols].max()),
        "categorical_items_LR": cat_lr, "categorical_items_df": cat_df, "categorical_items_p": cat_p,
        "categorical_aic": float(rcat.aic), "D1_extension": d1_res, "D81_extension": d8_res,
        "ame_P_B10_ge_4_per_point": ame, "wider_sample_n": len(full),
        "packages": {m.__name__: m.__version__ for m in (np, pd, sm, matplotlib)},
    }
    (HERE / "results.json").write_text(json.dumps(results, indent=2, default=float))
    print(json.dumps(results, indent=2, default=float))
    for t in (coef, group_or, pp, scen, sens_df, cat_terms, brant):
        print(t.round(3).to_string())
    print(vif.round(2).to_string())


def write_tables(coef, cuts, blocks, res, ll0, lr, lr_p, k, n, pp, group_or, int_lr, int_p,
                 scen, brant, vif, sens, d1, d8, cat_lr, cat_df, cat_p, n_cs, cells):
    rows = []
    for _, r in coef.iterrows():
        rows.append(f"{tex(r.term)} & {r.beta:.3f} & {r.se:.3f} & {r.OR:.2f} & [{r.OR_low:.2f}, {r.OR_high:.2f}] & {fmt_p(r.p)} \\\\")
        if r.term == NAT:
            rows.append(r"\midrule \multicolumn{6}{l}{\textit{Controls (references: female, student, 18--20 years, English, single)}} \\")
    cut_txt = ", ".join(f"$\\tau_{i+1}={c:.2f}$" for i, c in enumerate(cuts))
    (HERE / "table_ordinal.tex").write_text(rf"""\begin{{table}}[htbp]
\centering
\caption{{Primary ordinal logistic regression of overall readiness (B10) among single and engaged respondents ($n={n}$).}}
\label{{tab:ordinal}}
\small
\resizebox{{\ifdim\width>\linewidth\linewidth\else\width\fi}}{{!}}{{%
\begin{{tabular}}{{lrrrcr}}
\toprule
Term & $\hat\beta$ & SE & OR & 95\% CI (OR) & $p$ \\
\midrule
\multicolumn{{6}}{{l}}{{\textit{{Core items (1--5 agreement, per one-category increase)}}}} \\
{chr(10).join(rows)}
\midrule
\multicolumn{{6}}{{l}}{{Log-likelihood {res.llf:.1f} (threshold-only {ll0:.1f}); LR $\chi^2({k})={lr:.1f}$, {ptxt(lr_p)}; McFadden $R^2={1 - res.llf / ll0:.3f}$}} \\
\multicolumn{{6}}{{l}}{{Six core items jointly: LR $\chi^2({blocks['items'][1]})={blocks['items'][0]:.1f}$, {ptxt(blocks['items'][2])}; controls jointly: $\chi^2({blocks['controls'][1]})={blocks['controls'][0]:.1f}$, {ptxt(blocks['controls'][2])}}} \\
\bottomrule
\end{{tabular}}}}

\vspace{{2pt}}
\parbox{{0.95\linewidth}}{{\footnotesize \textit{{Note:}} OR $>1$ indicates higher odds of a higher B10 category. Thresholds: {cut_txt}. Respondents reporting both roles are coded as students. Estimates are from synthetic data and are not population estimates.}}
\end{{table}}
""", encoding="utf8")

    prow = "\n".join(
        f"{int(r.B10)} & {100*r['Emirati']:.1f} [{100*r['Emirati_low']:.1f}, {100*r['Emirati_high']:.1f}] & "
        f"{100*r['Non-Emirati']:.1f} [{100*r['Non-Emirati_low']:.1f}, {100*r['Non-Emirati_high']:.1f}] & "
        f"{100*r['diff']:+.1f} [{100*r['diff_low']:+.1f}, {100*r['diff_high']:+.1f}] \\\\" for _, r in pp.iterrows())
    cell_txt = "; ".join(tex(c.replace(" / ", ", ").lower()) for c in cells)
    (HERE / "table_predprob.tex").write_text(rf"""\begin{{table}}[htbp]
\centering
\caption{{Covariate-standardised probability (\%) of each B10 response for Emirati and non-Emirati respondents on the common-support set ($n={n_cs}$).}}
\label{{tab:predprob}}
\small
\resizebox{{\ifdim\width>\linewidth\linewidth\else\width\fi}}{{!}}{{%
\begin{{tabular}}{{cccc}}
\toprule
B10 & Emirati & Non-Emirati & Difference (pp) \\
\midrule
{prow}
\bottomrule
\end{{tabular}}}}

\vspace{{2pt}}
\parbox{{0.92\linewidth}}{{\footnotesize \textit{{Note:}} Each respondent's covariates are retained and nationality is set to each value in turn. The common-support set contains the role $\times$ age-group cells with at least three respondents from each group ({cell_txt}). 95\% intervals in brackets from {S} draws of the estimated parameter distribution. B10: ``Overall, I consider myself ready for family formation'' (1 = strongly disagree, 5 = strongly agree).}}
\end{{table}}
""", encoding="utf8")

    grow = "\n".join(f"{tex(r.term)} & {r.OR_emi:.2f} [{r.lo_emi:.2f}, {r.hi_emi:.2f}] & "
                     f"{r.OR_non:.2f} [{r.lo_non:.2f}, {r.hi_non:.2f}] & {fmt_p(r.p_diff)} \\\\" for r in group_or.itertuples())
    (HERE / "table_group_or.tex").write_text(rf"""\begin{{table}}[htbp]
\centering
\caption{{Odds ratios of the six core items for Emirati and non-Emirati respondents, from the secondary model with nationality $\times$ item interactions ($n={n}$).}}
\label{{tab:group_or}}
\small
\resizebox{{\ifdim\width>\linewidth\linewidth\else\width\fi}}{{!}}{{%
\begin{{tabular}}{{lccr}}
\toprule
Core item & Emirati OR [95\% CI] & Non-Emirati OR [95\% CI] & $p$ (difference) \\
\midrule
{grow}
\bottomrule
\end{{tabular}}}}

\vspace{{2pt}}
\parbox{{0.95\linewidth}}{{\footnotesize \textit{{Note:}} Joint test of the six interactions: LR $\chi^2({len(group_or)})={int_lr:.1f}$, {ptxt(int_p)}. Item-level $p$-values are exploratory and unadjusted for multiplicity. Controls as in Table~\ref{{tab:ordinal}}.}}
\end{{table}}
""", encoding="utf8")

    srow = []
    for g in ["Emirati", "Non-Emirati"]:
        sg = scen[scen.group == g]
        srow.append(rf"\multicolumn{{3}}{{l}}{{\textit{{{g} ($n={sg.n.iloc[0]}$), baseline {100*sg.baseline.iloc[0]:.1f}\%}}}} \\")
        srow += [f"\\quad {tex(r.item)} & {100*r.delta:+.1f} [{100*r.low:+.1f}, {100*r.high:+.1f}] & {100*r.share_at_5:.0f} \\\\"
                 for r in sg.itertuples()]
    (HERE / "table_scenarios.tex").write_text(rf"""\begin{{table}}[htbp]
\centering
\caption{{Monte Carlo scenarios: change in the mean predicted probability of agreeing or strongly agreeing with B10 ($\Pr(Y\geq4)$) when one item is raised by one category for every respondent.}}
\label{{tab:scenarios}}
\small
\resizebox{{\ifdim\width>\linewidth\linewidth\else\width\fi}}{{!}}{{%
\begin{{tabular}}{{lcc}}
\toprule
Scenario & Change in $\Pr(Y\geq4)$, pp [95\% interval] & Already at 5 (\%) \\
\midrule
{chr(10).join(srow)}
\bottomrule
\end{{tabular}}}}

\vspace{{2pt}}
\parbox{{0.95\linewidth}}{{\footnotesize \textit{{Note:}} Values are capped at 5, so respondents already at the top category are unchanged. Intervals reflect parameter uncertainty only ({S} draws). Scenarios compare predictions at different reported conditions; they are not effects of providing employment, housing or financial support.}}
\end{{table}}
""", encoding="utf8")

    item_cols = list(ITEMS)
    b = brant.set_index("term")
    ncol = 4 + len(sens.columns) - 1
    drow = "\n".join(f"{tex(t)} & {b.chi2[t]:.2f} & {fmt_p(b.p[t])} & {vif[t]:.2f} & " +
                     " & ".join(f"{v:.2f}" for v in sens.loc[t].values[1:]) + r" \\" for t in item_cols + [NAT])
    heads = " & ".join(sens.columns[1:])
    (HERE / "table_diagnostics.tex").write_text(rf"""\begin{{table}}[htbp]
\centering
\caption{{Diagnostics and sensitivity of the primary model: Brant test of proportional odds (3 df per term), variance inflation factors and odds ratios under alternative specifications.}}
\label{{tab:diagnostics}}
\small
\resizebox{{\ifdim\width>\linewidth\linewidth\else\width\fi}}{{!}}{{%
\begin{{tabular}}{{lccc{'c' * (len(sens.columns) - 1)}}}
\toprule
 & \multicolumn{{2}}{{c}}{{Brant}} & & \multicolumn{{{len(sens.columns) - 1}}}{{c}}{{OR under alternative specification}} \\
\cmidrule(lr){{2-3}} \cmidrule(lr){{5-{ncol}}}
Term & $\chi^2$ & $p$ & VIF & {heads} \\
\midrule
{drow}
\bottomrule
\end{{tabular}}}}

\vspace{{2pt}}
\parbox{{0.95\linewidth}}{{\footnotesize \textit{{Note:}} Brant omnibus $\chi^2({int(b.df['Omnibus'])})={b.chi2['Omnibus']:.1f}$, {ptxt(b.p['Omnibus'])}. Wider sample adds married and divorced/widowed respondents and replaces the engaged indicator with marital-status indicators. The D8.1 subset comprises respondents who named a programme, reported being eligible and rated its usefulness. Extensions on their own subsets: D1 ($n={d1['n']}$, {d1['n_none']} non-recognisers) OR {d1['OR']:.2f} [{d1['low']:.2f}, {d1['high']:.2f}], {ptxt(d1['p'])}; D8.1 ($n={d8['n']}$) OR {d8['OR']:.2f} [{d8['low']:.2f}, {d8['high']:.2f}], {ptxt(d8['p'])}. Categorical versus linear item coding: LR $\chi^2({cat_df})={cat_lr:.1f}$, {ptxt(cat_p)}.}}
\end{{table}}
""", encoding="utf8")


def style(ax):
    for s in ["top", "right"]:
        ax.spines[s].set_visible(False)
    for s in ["left", "bottom"]:
        ax.spines[s].set_color(MUTED)
    ax.tick_params(colors=MUTED, labelcolor=INK)


def figures(coef, pp, item_cols):
    plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 9})
    c = coef[coef.term.isin(item_cols + [NAT])].iloc[::-1]
    fig, ax = plt.subplots(figsize=(6.2, 3.2))
    yy = np.arange(len(c))
    ax.axvline(1, color=MUTED, lw=1, ls="--", zorder=1)
    ax.hlines(yy, c.OR_low, c.OR_high, color=BLUE, lw=2, zorder=2)
    ax.scatter(c.OR, yy, s=40, color=BLUE, edgecolor="white", linewidth=1.5, zorder=3)
    for i, r in enumerate(c.itertuples()):
        ax.text(r.OR_high * 1.03, i, f"{r.OR:.2f}", va="center", fontsize=8, color=INK)
    ax.set_yticks(yy, c.term); ax.set_xscale("log")
    lo, hi = c.OR_low.min(), c.OR_high.max()
    ticks = [t for t in [0.25, 0.5, 0.75, 1, 1.5, 2, 3, 4, 6] if lo / 1.3 <= t <= hi * 1.3]
    ax.set_xticks(ticks, [f"{t:g}" for t in ticks]); ax.minorticks_off()
    ax.set_xlabel("Odds ratio for a higher B10 category (95% CI, log scale)", color=INK)
    ax.grid(axis="x", color=GRID, lw=0.8); ax.set_axisbelow(True)
    style(ax); fig.tight_layout()
    fig.savefig(HERE / "fig_odds_ratios.pdf"); fig.savefig(HERE / "fig_odds_ratios.png", dpi=200); plt.close(fig)

    fig, ax = plt.subplots(figsize=(6.2, 3.0))
    w = 0.36
    for off, g, col in [(-w/2 - 0.01, "Emirati", BLUE), (w/2 + 0.01, "Non-Emirati", ORANGE)]:
        h = pp[g].to_numpy()
        ax.bar(pp.B10 + off, h, width=w, color=col, label=g, zorder=2)
        ax.errorbar(pp.B10 + off, h, yerr=[h - pp[f"{g}_low"], pp[f"{g}_high"] - h], fmt="none",
                    ecolor=INK, elinewidth=1, capsize=2, zorder=3)
    ax.set_xticks(range(1, 6), ["1\nStrongly disagree", "2", "3", "4", "5\nStrongly agree"])
    ax.set_xlabel("B10 overall family-formation readiness", color=INK)
    ax.set_ylabel("Predicted probability", color=INK)
    ax.yaxis.set_major_formatter(matplotlib.ticker.PercentFormatter(1, decimals=0))
    ax.grid(axis="y", color=GRID, lw=0.8); ax.set_axisbelow(True)
    ax.legend(frameon=False, loc="upper right"); style(ax); fig.tight_layout()
    fig.savefig(HERE / "fig_predicted_probabilities.pdf"); fig.savefig(HERE / "fig_predicted_probabilities.png", dpi=200)
    plt.close(fig)


if __name__ == "__main__":
    main()
