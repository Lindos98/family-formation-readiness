# Ordinal regression results (Fangzhou) – Assignment 3

This folder contains the main analysis for Assignment 3. It reports an ordinal logistic regression of overall family-formation readiness (B10), fitted to `Updated Synthetic Data.xlsx` and following the specification agreed in Assignment 2. It provides the main-analysis part of the **Results** section and the related points for the **Limitations** section.

## How to add it to the Overleaf project

1. Upload this whole `ordinal_regression/` folder to the **root** of the Overleaf project, at the same level as the main `.tex` file. All paths in the `.tex` files assume this location.
2. In the Results section, add:
   ```latex
   \input{ordinal_regression/results_ordinal}
   ```
   Alanoud's descriptive results should come **before** this line.
3. In the Limitations section, add:
   ```latex
   \input{ordinal_regression/limitations_ordinal}
   ```

The required packages (`graphicx`, `booktabs`) and all cited references (`king2000`, `brant1990`, `rehim2023delayed`, `almazrouei2026delayed`, `albahar2026marriage`, `vignoli2020reflection`) are already in the project's preamble and `references.bib`, so nothing else needs to change.

Both main files compile with this folder without errors or overfull tables:

- **`main_v2.tex`** (recommended): place a new `sections/08_results.tex` between `\input{sections/05_moza}` and `\input{sections/06_feasibility}`.
- **`main_v1.tex`**: add `\section{Results}` and the `\input` line immediately before `\section{Feasibility, Risks, and Limitations}`. Add the limitations `\input` under `\subsection{Study Limitations}`.

**Please note:** the text begins by referring to `Section~\ref{sec:model}` for the model specification. In `main_v2.tex`, this points to the full Assignment 2 model section. In `main_v1.tex`, Section 3 contains headings only. If `main_v1.tex` remains the main document, either restore the model section or replace that reference with a one-sentence description.

## Contents

| File | Purpose |
|---|---|
| `results_ordinal.tex` | Results text, in four subsections: factors associated with readiness; Emirati vs non-Emirati comparison; scenario predictions; diagnostics and robustness |
| `limitations_ordinal.tex` | Five limitations arising from this analysis, written to be merged into the Limitations section |
| `table_ordinal.tex` | Table: primary ordinal model (`tab:ordinal`) |
| `table_predprob.tex` | Table: predicted B10 distribution by nationality (`tab:predprob`) |
| `table_group_or.tex` | Table: odds ratios by nationality from the interaction model (`tab:group_or`) |
| `table_scenarios.tex` | Table: Monte Carlo scenarios for C1, C9 and C14 (`tab:scenarios`) |
| `table_diagnostics.tex` | Table: Brant test, VIF and sensitivity analyses (`tab:diagnostics`) |
| `fig_odds_ratios.pdf` | Figure: odds ratios with 95% CIs (`fig:odds_ratios`) |
| `fig_predicted_probabilities.pdf` | Figure: predicted B10 distribution by nationality (`fig:predprob`) |
| `code/run_ordinal.py` | Script that produces every table, figure and number above |
| `code/results.json` | All reported statistics, the sample flow and the SHA-256 hash of the input data |
| `code/requirements.txt` | Python package versions used (Python 3.12) |

Overleaf does not need the `code/` folder to compile. It is included so that the results can be reproduced and checked.

## Analysis decisions (for consistency across sections)

- **Primary population:** single or engaged respondents with a known nationality, as specified in Assignment 2. The sample flow is 700 responses → 691 with known nationality → 407 single or engaged → **396 analysed** after excluding 11 respondents who did not report gender or age group. The analysed sample comprises 289 Emirati and 107 non-Emirati respondents, of whom 34 are engaged.
- **Core predictors:** C1, C9, C14, E3, E13 and F9, each coded 1–5.
- **Controls:** gender, student/employee role (respondents reporting both roles are coded as students), age group, questionnaire language and an engaged indicator.
- **Deviation from the plan:** the age groups 31–40, 41–50 and 51+ were merged into "31 or above", because only seven single or engaged Emirati respondents were older than 30. This change is stated in the text.
- **Nationality comparison:** predictions are restricted to the 378 respondents in role × age-group cells with at least three respondents from each nationality group (common support).
- **Wider sample (sensitivity analysis):** 655 respondents of all marital statuses.

When reporting descriptive statistics, please state the denominator (700, 691, 407 or 396) so that it is clear how they relate to the model sample.

## Main results

- Financial preparedness (C14) has the strongest association with readiness (OR 1.83). It is followed by housing access (C9, 1.40), family support (E3, 1.31) and employment confidence (C1, 1.27). E13 and F9 show no association.
- The adjusted nationality difference is weak and imprecise: OR 1.75, 95% CI 0.98–3.14, p = 0.058.
- The nationality × item interactions are jointly significant (p = 0.005). Family support (E3) is associated with readiness only among Emirati respondents (OR 1.66 vs 0.84). Financial preparedness shows a stronger association among non-Emirati respondents (2.48 vs 1.63); this comparison is exploratory.
- Raising C14 by one category increases the predicted share agreeing with B10 by 11.2 percentage points for Emirati respondents and 8.7 points for non-Emirati respondents. These scenarios are not causal effects.
- The D1 awareness extension cannot be interpreted, because all 12 non-recognisers are non-Emirati. The D8.1 usefulness extension (n = 130) adds no information. The proportional-odds assumption holds (Brant omnibus p = 0.80).

## Reproducing the results

```
pip install -r code/requirements.txt
python code/run_ordinal.py "path/to/Updated Synthetic Data.xlsx"
```

The script does not modify the data file. It writes the tables, figures, CSV files and `results.json` into `code/`. The random seed is 701, and the Monte Carlo intervals use 1,000 draws.
